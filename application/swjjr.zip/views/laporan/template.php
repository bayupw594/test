<!DOCTYPE html>
<html>
<head>
	<title>Laporan</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/laporan.css">
</head>
<body>
	<div class="header"><img src="<?php echo base_url();?>img/kaldera_logo.png" /></div>
</body>
</html>